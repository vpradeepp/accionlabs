/**
 * 
 */
package com.accion.constants;

/**
 * @author Pradeep
 *
 */
public class Constants {

	public static final String DRIVER_CHROME = "webdriver.chrome.driver";
	public static final String CHROME = "chrome";
	public static final String APP_URL = "http://automationpractice.com/index.php";
	public static final String EXPECTED_TITLE = "My Store";
	public static final String BLOUSE = "Blouse";
	public static final String CART_SUCCESS_MESSAGE = "Product successfully added to your shopping cart";
	public static final String EMAIL_ADDRESS = "v.pradeepp@gmail.com";
	public static final String PASSWORD = "password";
	public static final String EXPECTED_ERROR_MESSAGE = "Authentication failed.";
	
	
}
