 
/**
 * @author Pradeep
 *
 */
package com.accion.main;

import com.accion.practice.AutomationPractice;

class main{
	public static void main(String args[]){
		AutomationPractice automationPractice = new AutomationPractice();
		automationPractice.launchwebPage();
	}
}