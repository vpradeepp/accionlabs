 
/**
 * @author Pradeep
 *
 */
package com.accion.practice;

import org.openqa.selenium.By;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.accion.constants.Constants;
import com.accion.reusablelib.ReusableLibrary;

public class AutomationPractice extends ReusableLibrary{
	WebDriver webDriver = null;
	String actualTitle = null;
	WebDriverWait webDriverWait = null;
			
	
	public void launchwebPage() {
		webDriver = launchDriver(Constants.CHROME);
		navigateToApplication(webDriver);		
	}
	
	private void navigateToApplication(WebDriver webDriver) {
		webDriver.navigate().to(Constants.APP_URL);  	
		actualTitle = webDriver.getTitle();
		
		implicitlyWait(webDriver);
		maximizeWindow(webDriver);
		
		if(Constants.EXPECTED_TITLE.trim().equalsIgnoreCase(actualTitle.trim())){
			System.out.println("Expected Title " + Constants.EXPECTED_TITLE.trim() + " is matched sucessfully withe the Actual title");
		}else{
			System.out.println("Expected Title " + Constants.EXPECTED_TITLE.trim() + " is not matched sucessfully withe the Actual title");
		}
		
		/**
		 * Scenario 1: 						 
		 */
		searchProductAndValidate();
		
		/**
		 * Scenario 2: 
		 */
		
		addProductToCart();
		
		/**
		 * Scenario 3:
		 */
		
		validateMoreButton();
		
		/**
		 * Scenario 4:
		 */
		
		validateLoginPage();
		
		/**
		 * Quit the browser
		 */
		closeBrowser(webDriver);
		
	}
	

	/**
	 * Scenario 3 : Scroll down to a product to a mouse over and click on More, validate the
			resulting page has the correct information and also the functionality in that page is
			working by validating increment and decrement of quantity, size and then Add to
			Cart
	 */

	private void validateMoreButton() {
		
		WebElement clickMoreButton  = null;
		WebElement clickPlusButton  = null;
		WebElement moveToProduct = null;
		WebElement clickAddToCart = null;
		WebElement getMessageWebelement = null;
		WebElement getProductNameWebelement = null;
		WebElement getProductNameinMoreWebelement = null;
		WebElement clickCloseButton = null;
		WebElement moveToCart = null;
		WebElement cartQtyWebelement = null;
		
		String getProductName = null;
		String getProductNameinMoreScreen = null;
		String getQty = null;
		
		
		moveToProduct = webDriver.findElement(By.xpath("//div[contains(@class,'right-block')]//a[@title='Faded Short Sleeve T-shirts']"));
		moveToElement(webDriver, moveToProduct);    	
		
		getProductNameWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'right-block')]//a[@title='Faded Short Sleeve T-shirts']"));
		getProductName = getText(getProductNameWebelement);	
		System.out.println("Product Name before click the MORE button: " + getProductName);
		
		clickMoreButton = webDriver.findElement(By.xpath("//div[contains(@class,'button-container')]//a[@title='View' and (@class='button lnk_view btn btn-default')][1]"));
		clickElement(clickMoreButton);	
		
		
		getProductNameinMoreWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'pb-center-column col-xs-12 col-sm-4')]//h1"));
		getProductNameinMoreScreen = getText(getProductNameinMoreWebelement);	
		System.out.println("Product Name in MORE Screen: " + getProductNameinMoreScreen);
		
		
		if(getProductNameinMoreScreen.trim().equalsIgnoreCase(getProductName)){
			System.out.println("Products are matched with each other");
		}else{
			System.out.println("Products are not matched with each other");
		}
		
		for(int i=1;i<=3;i++){
			clickPlusButton = webDriver.findElement(By.xpath("//a[contains(@class,'btn btn-default button-plus product_quantity_up')]"));
			clickElement(clickPlusButton);	
		}
			
		clickAddToCart = webDriver.findElement(By.xpath("//div[contains(@class,'box-cart-bottom')]//button[@type='submit']"));
		clickElement(clickAddToCart);	
		
		clickCloseButton = webDriver.findElement(By.xpath("//div[contains(@class,'layer_cart_product col-xs-12 col-md-6')]/span"));
		clickElement(clickCloseButton);
		
		moveToCart = webDriver.findElement(By.xpath("//div[contains(@class,'shopping_cart')]//a[@title='View my shopping cart']"));
		moveToElement(webDriver, moveToCart); 
		
				
		cartQtyWebelement = webDriver.findElement(By.xpath("//span[contains(@class,'ajax_cart_quantity')]"));
		getQty = getText(cartQtyWebelement);
		 
		if(4 == Integer.parseInt(getQty)){
			System.out.println("Quantity are matched in Cart");
		}else{
			System.out.println("Quantity are not matched in Cart");
		}
	}

	/**
	 * Scenario 4: Create a login page failure validation
	 */
	
	private void validateLoginPage() {
		WebElement clickSigninButton = null;
		WebElement emailAddress = null;
		WebElement password = null;
		WebElement clickSignIn = null;
		WebElement moveToSignIn = null;
		WebElement errorMesssageWebelement = null;
		
		String getErrorMessage = null;
		
		moveToSignIn = webDriver.findElement(By.xpath("//div[contains(@class,'header_user_info')]//a"));
		moveToElement(webDriver, moveToSignIn);
		
		clickSigninButton = webDriver.findElement(By.xpath("//div[contains(@class,'header_user_info')]//a"));
		clickElement(clickSigninButton);	
		
		emailAddress = webDriver.findElement(By.xpath("//label[contains(.,'Email address')]/following-sibling::input[@id='email']"));
		typeTextinTextBox(emailAddress, Constants.EMAIL_ADDRESS);
		
		emailAddress = webDriver.findElement(By.xpath("//div[contains(@class,'form-group')]//input[@id='passwd']"));
		typeTextinTextBox(emailAddress, Constants.PASSWORD);	
		
		clickSignIn = webDriver.findElement(By.xpath("//button[contains(@class,'button btn btn-default button-medium') and @id='SubmitLogin']"));
		clickElement(clickSignIn);
		
		errorMesssageWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'alert alert-danger')]//ol"));
		getErrorMessage = getText(errorMesssageWebelement);
		System.out.println("Error Message : " + getErrorMessage);
		
		if(Constants.EXPECTED_ERROR_MESSAGE.equalsIgnoreCase(getErrorMessage)){
			System.out.println("Login Failed and the Error Messsage is : " + getErrorMessage);
		}else{
			System.out.println("Sucessfully Logged-in : ");
		}
		
		
		
	}

	/**
	 * Scenario 2: Scroll down from the homepage and add a product to cart and validate
					the addition of the product is successful to the cart.
	 */

	private void addProductToCart() {
		WebElement clickAddtoCart  = null;
		WebElement moveToProduct = null;
		WebElement clickCloseButton = null;
		WebElement getMessageWebelement = null;
		WebElement getProductNameWebelement = null;
		WebElement moveToCart = null;
		WebElement clearCart = null;
		
		String getProductName = null;
		String getCartMessage = null;
		
		webDriverWait =   new WebDriverWait(webDriver, 20);
		
		WebElement getProductNameFromCartWebelement = null;
		String getProductNameFromCart = null;
			
		webDriver.navigate().to(Constants.APP_URL);  		
		scrollPageDown(webDriver);
		
		moveToProduct = webDriver.findElement(By.xpath("//div[contains(@class,'product-image-container')]//img[@title='Faded Short Sleeve T-shirts']"));
		moveToElement(webDriver, moveToProduct);    	
		
		getProductNameWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'right-block')]//a[@title='Faded Short Sleeve T-shirts']"));
		getProductName = getText(getProductNameWebelement);	
		System.out.println("Product Name before adding to CART: " + getProductName);
		
		clickAddtoCart = webDriver.findElement(By.xpath("//div[contains(@class,'button-container')]//a[@title='Add to cart' and (@data-id-product='1')]"));
		clickElement(clickAddtoCart);	
		
		webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'layer_cart_product col-xs-12 col-md-6')]//h2")));
		
		getMessageWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'layer_cart_product col-xs-12 col-md-6')]//h2"));
		getCartMessage = getText(getMessageWebelement);
		System.out.println("CART Message : " + getCartMessage);
		
		if(Constants.CART_SUCCESS_MESSAGE.equalsIgnoreCase(getCartMessage)){
			System.out.println("Product has been successfully added to cart and the message is " + getCartMessage);
		}else{
			System.out.println("Product has not added to cart and the message is " + getCartMessage);
		}
				
		clickCloseButton = webDriver.findElement(By.xpath("//div[contains(@class,'layer_cart_product col-xs-12 col-md-6')]/span"));
		clickElement(clickCloseButton);
		
		moveToCart = webDriver.findElement(By.xpath("//div[contains(@class,'shopping_cart')]//a[@title='View my shopping cart']"));
		moveToElement(webDriver, moveToCart); 
		
		getProductNameFromCartWebelement = webDriver.findElement(By.xpath("//div[contains(@class,'product-name')]//a"));
		getProductNameFromCart = getProductNameFromCartWebelement.getAttribute("title");
		//getProductNameFromCart = getText(getProductNameFromCartWebelement);	
		System.out.println("Product Name after adding to CART: " + getCartMessage);
		
		if(getProductNameFromCart.equalsIgnoreCase(getProductName)){
			System.out.println("Product: " + getProductNameFromCart + " is added sucessfully");
		}else{
			System.out.println("Product: " + getProductNameFromCart + " is not added");
		}
		
		//Clear the cart value
		clearCart = webDriver.findElement(By.xpath("//a[contains(@class,'ajax_cart_block_remove_link')]"));
		clickElement(clearCart);
		
		
	}

	
	/**
	 * Scenario 1: Search a product and validate that the search result is the correct
					product being displayed
	 */
	private void searchProductAndValidate() {
		 
		WebElement searchProduct = null;
		WebElement clickElement  = null;
		WebElement getTextWebElement  = null;
		String getText = null;
		
		searchProduct = webDriver.findElement(By.xpath("//input[contains(@class,'search_query form-control ac_input') and @id='search_query_top']"));
		typeTextinTextBox(searchProduct, Constants.BLOUSE);
		
		clickElement = webDriver.findElement(By.xpath("//button[contains(@class,'btn btn-default button-search') and @type='submit']"));
		clickElement(clickElement);
		
		scrollPageDown(webDriver);
		
		getTextWebElement = webDriver.findElement(By.xpath("//div[contains(@class,'right-block')]//a[contains(@class,'product-name')]"));
		getText = getText(getTextWebElement);
		
		if(Constants.BLOUSE.equalsIgnoreCase(getText)){
			System.out.println("The product " + getText + " was sucessfully retrived");
		}else{
			System.out.println("The product " + getText + " was not retrived");
		}		
		
	}

	

	
	
		
}

