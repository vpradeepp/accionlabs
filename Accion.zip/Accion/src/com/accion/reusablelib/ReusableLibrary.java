/**
 * @author Pradeep
 *
 */

package com.accion.reusablelib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.accion.constants.Constants;

public class ReusableLibrary{
	
	JavascriptExecutor javascriptExecutor = null;
	
	public WebDriver launchDriver(String driverName){
		WebDriver webDriver = null;
		if(Constants.CHROME.equalsIgnoreCase(driverName)){
			System.setProperty(Constants.DRIVER_CHROME, "D:\\workspace\\Testing\\Accion\\jars\\chromedriver.exe");
			webDriver = new ChromeDriver();
		}
		
		return webDriver;
	}
	
	
	public void maximizeWindow(WebDriver webDriver) {
		webDriver.manage().window().maximize();
	}
	
	public void implicitlyWait(WebDriver webDriver) {
		webDriver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;		
	}
	
	public void typeTextinTextBox(WebElement webElement, String inputText){
		webElement.sendKeys(inputText);
	}
	
	public void clickElement(WebElement clickElement) {		 
		clickElement.click();
	}
	
	public void scrollPageDown(WebDriver webDriver){
		javascriptExecutor = (JavascriptExecutor) webDriver;
		javascriptExecutor.executeScript("window.scrollBy(0,800)");
	}
	
	public String getText(WebElement getTextWebElement) {
		return getTextWebElement.getText();
		
	}
	
	public void moveToElement(WebDriver webDriver, WebElement moveToProduct) {
		Actions actions = new Actions(webDriver);	
		actions.moveToElement(moveToProduct).perform();
	}
	
	public void closeBrowser(WebDriver webDriver) {
		webDriver.quit();
	}

}